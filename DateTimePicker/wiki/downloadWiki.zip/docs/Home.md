/// <summary>
  /// Follow steps 1a or 1b and then 2 to use this custom control in a XAML file.
  ///
  /// Step 1a) Using this custom control in a XAML file that exists in the current project.
  /// Add this XmlNamespace attribute to the root element of the markup file where it is 
  /// to be used:
  ///
  ///     xmlns:MyNamespace="clr-namespace:DateTimePicker"
  ///
  ///
  /// Step 1b) Using this custom control in a XAML file that exists in a different project.
  /// Add this XmlNamespace attribute to the root element of the markup file where it is 
  /// to be used:
  ///
  ///     xmlns:MyNamespace="clr-namespace:DateTimePicker;assembly=DateTimePicker"
  ///
  /// You will also need to add a project reference from the project where the XAML file lives
  /// to this project and Rebuild to avoid compilation errors:
  ///
  ///     Right click on the target project in the Solution Explorer and
  ///     "Add Reference"->"Projects"->[Browse to and select this project](Browse-to-and-select-this-project)
  ///
  ///
  /// Step 2)
  /// Go ahead and use your control in the XAML file.
  ///
  ///     <MyNamespace:DateTimePicker/>
  ///
  /// </summary>


**{"****"}Delete the following note before publishing {"****"}**

This project is currently in setup mode and only available to project coordinators and developers. Once you have finished setting up your project you can publish it to make it available to all CodePlex visitors.

There are three requirements before you publish:

- Edit this page to provide information about your project
- Upload the initial source code for your project
- Add your project license

Additional information on starting a new project is available here: [Project Startup Guide](http://www.codeplex.com/Wiki/View.aspx?ProjectName=CodePlex&title=CodePlex%20Project%20Startup%20Guide).